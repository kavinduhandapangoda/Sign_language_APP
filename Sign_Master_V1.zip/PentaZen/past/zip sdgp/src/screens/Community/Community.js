import React from 'react'


const Community = () => {
    return (
        <div className="screens">
            <h1>Community</h1>
            
        </div>
    )
}

export default Community

