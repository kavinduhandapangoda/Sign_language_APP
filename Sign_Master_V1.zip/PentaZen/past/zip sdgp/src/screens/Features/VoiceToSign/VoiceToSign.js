import React from 'react'

const VoiceToSign = () => {
    return (
        <div className="screens">
            <h1>VoiceToSign</h1>
        </div>
    )
}

export default VoiceToSign
