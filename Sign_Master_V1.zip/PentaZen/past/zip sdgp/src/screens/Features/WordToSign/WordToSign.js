import React from 'react'

const WordToSign = () => {
    return (
        <div className="screens">
            <h1>WordToSign</h1>
        </div>
    )
}

export default WordToSign
