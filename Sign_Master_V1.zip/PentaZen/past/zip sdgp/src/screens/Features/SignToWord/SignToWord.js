import React from 'react'

const SignToWord = () => {
    return (
        <div className="screens">
            <h1>SignToWord</h1>
        </div>
    )
}

export default SignToWord
