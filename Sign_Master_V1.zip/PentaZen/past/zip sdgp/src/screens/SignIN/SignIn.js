import React from 'react'

const SignIn = () => {
    return (
        <div className="screens">
            <h1>SignIn</h1>
            
        </div>
    )
}

export default SignIn
